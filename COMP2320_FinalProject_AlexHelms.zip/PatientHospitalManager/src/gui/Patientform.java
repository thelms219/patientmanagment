package gui;

import model.Doctor;
import model.Medication;
import model.Nurse;
import model.Patient;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

/**
 * form for creating or editing a Patient
 */
public class Patientform extends JPanel {
	private JTextField tfFirstName;
	private JTextField tfLastName;
	private JTextField tfPatientID;
	private JComboBox<Doctor> doctorDropdown;
	private JComboBox<Nurse> nurseDropdown;
	private JTextField tfMedicationName;
	private JTextField tfMedicationDosage;
	private DefaultListModel<Medication> medicationListModel;
	private JTextArea taNotes;

	private final java.awt.event.ActionListener onSubmit;

	public Patientform(Patient existingPatient, List<Doctor> doctors, List<Nurse> nurses,
			java.awt.event.ActionListener onSubmit) {
		this.onSubmit = onSubmit;
		setLayout(null);

		initializeFields();
		populateDoctorDropdown(doctors);
		populateNurseDropdown(nurses);

		if (existingPatient != null) {
			populateFields(existingPatient);
		}
	}

	private void initializeFields() {
		// first name
		JLabel lblFirstName = new JLabel("First Name:");
		lblFirstName.setBounds(50, 20, 100, 25);
		add(lblFirstName);

		tfFirstName = new JTextField();
		tfFirstName.setBounds(150, 20, 200, 25);
		add(tfFirstName);

		// last name
		JLabel lblLastName = new JLabel("Last Name:");
		lblLastName.setBounds(50, 60, 100, 25);
		add(lblLastName);

		tfLastName = new JTextField();
		tfLastName.setBounds(150, 60, 200, 25);
		add(tfLastName);

		// ID
		JLabel lblPatientID = new JLabel("Patient ID:");
		lblPatientID.setBounds(50, 100, 100, 25);
		add(lblPatientID);

		tfPatientID = new JTextField();
		tfPatientID.setBounds(150, 100, 200, 25);
		add(tfPatientID);

		// assign dr
		JLabel lblAssignDoctor = new JLabel("Assign Doctor:");
		lblAssignDoctor.setBounds(50, 140, 100, 25);
		add(lblAssignDoctor);

		doctorDropdown = new JComboBox<>();
		doctorDropdown.setBounds(150, 140, 200, 25);
		add(doctorDropdown);

		// assign nurse
		JLabel lblAssignNurse = new JLabel("Assign Nurse:");
		lblAssignNurse.setBounds(50, 180, 100, 25);
		add(lblAssignNurse);

		nurseDropdown = new JComboBox<>();
		nurseDropdown.setBounds(150, 180, 200, 25);
		add(nurseDropdown);

		// medication
		JLabel lblMedicationName = new JLabel("Medication Name:");
		lblMedicationName.setBounds(50, 220, 120, 25);
		add(lblMedicationName);

		tfMedicationName = new JTextField();
		tfMedicationName.setBounds(180, 220, 170, 25);
		add(tfMedicationName);

		JLabel lblMedicationDosage = new JLabel("Dosage (mg):");
		lblMedicationDosage.setBounds(50, 260, 120, 25);
		add(lblMedicationDosage);

		tfMedicationDosage = new JTextField();
		tfMedicationDosage.setBounds(180, 260, 170, 25);
		add(tfMedicationDosage);

		JButton btnAddMedication = new JButton("Add Medication");
		btnAddMedication.setBounds(180, 300, 170, 30);
		btnAddMedication.addActionListener(e -> addMedication());
		add(btnAddMedication);

		medicationListModel = new DefaultListModel<>();
		JList<Medication> medicationList = new JList<>(medicationListModel);
		JScrollPane medicationScrollPane = new JScrollPane(medicationList);
		medicationScrollPane.setBounds(50, 340, 300, 100);
		add(medicationScrollPane);

		// notes
		JLabel lblNotes = new JLabel("Notes:");
		lblNotes.setBounds(50, 460, 100, 25);
		add(lblNotes);

		taNotes = new JTextArea();
		JScrollPane notesScrollPane = new JScrollPane(taNotes);
		notesScrollPane.setBounds(150, 460, 200, 100);
		add(notesScrollPane);

		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setBounds(150, 580, 200, 30);
		btnSubmit.addActionListener(e -> handleSubmit());
		add(btnSubmit);
	}

	private void populateDoctorDropdown(List<Doctor> doctors) {
		if (doctors != null) {
			for (Doctor doctor : doctors) {
				doctorDropdown.addItem(doctor);
			}
		}
	}

	private void populateNurseDropdown(List<Nurse> nurses) {
		if (nurses != null) {
			for (Nurse nurse : nurses) {
				nurseDropdown.addItem(nurse);
			}
		}
	}

	private void addMedication() {
		String medName = tfMedicationName.getText().trim();
		String medDosageText = tfMedicationDosage.getText().trim();

		try {
			if (medName.isEmpty()) {
				JOptionPane.showMessageDialog(this, "Medication name cannot be empty.", "Error",
						JOptionPane.ERROR_MESSAGE);
				return;
			}
			int medDosage = Integer.parseInt(medDosageText);
			if (medDosage <= 0) {
				JOptionPane.showMessageDialog(this, "Dosage must be a positive number.", "Error",
						JOptionPane.ERROR_MESSAGE);
				return;
			}

			Medication medication = new Medication(medName, medDosage);
			medicationListModel.addElement(medication);

			// resets the medication fields
			tfMedicationName.setText("");
			tfMedicationDosage.setText("");
		} catch (NumberFormatException ex) {
			JOptionPane.showMessageDialog(this, "Dosage must be a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void populateFields(Patient patient) {
		tfFirstName.setText(patient.getFirstName());
		tfLastName.setText(patient.getLastName());
		tfPatientID.setText(String.valueOf(patient.getId()));

		if (patient.getAssignedDoctor() != null) {
			doctorDropdown.setSelectedItem(patient.getAssignedDoctor());
		}

		if (patient.getAssignedNurse() != null) {
			nurseDropdown.setSelectedItem(patient.getAssignedNurse());
		}

		medicationListModel.clear();
		for (Medication medication : patient.getMedications()) {
			medicationListModel.addElement(medication);
		}

		taNotes.setText(patient.getNotes());
	}

	private void handleSubmit() {
		try {
			System.out.println("Starting handleSubmit...");

			// check for empty fields
			if (tfFirstName.getText().isEmpty() || tfLastName.getText().isEmpty() || tfPatientID.getText().isEmpty()) {
				JOptionPane.showMessageDialog(this, "All fields are required.", "Validation Error",
						JOptionPane.ERROR_MESSAGE);
				System.out.println("Validation failed: One or more fields are empty.");
				return;
			}

			// Log Patient ID input
			String patientIdInput = tfPatientID.getText().trim();
			System.out.println("Patient ID Input: " + patientIdInput);

			// Parse and validate Patient ID
			int patientID = Integer.parseInt(patientIdInput); // This should throw if invalid
			System.out.println("Parsed Patient ID: " + patientID);

			// Collect other input fields
			String firstName = tfFirstName.getText();
			String lastName = tfLastName.getText();
			Doctor doctor = (Doctor) doctorDropdown.getSelectedItem();
			Nurse nurse = (Nurse) nurseDropdown.getSelectedItem();
			String notes = taNotes.getText();

			System.out.println("Collected fields: FirstName=" + firstName + ", LastName=" + lastName);

			List<Medication> medications = new ArrayList<>();
			for (int i = 0; i < medicationListModel.size(); i++) {
				medications.add(medicationListModel.get(i));
			}
			System.out.println("Medications collected: " + medications);

			String patientData = String.format("%d;%s;%s;%s;%s;%s;%s", patientID, firstName, lastName,
					doctor != null ? doctor.toString() : "Unassigned", nurse != null ? nurse.toString() : "Unassigned",
					medications, notes);

			System.out.println("Patient Data Submitted: " + patientData);

			onSubmit.actionPerformed(
					new java.awt.event.ActionEvent(this, java.awt.event.ActionEvent.ACTION_PERFORMED, patientData));
			JOptionPane.showMessageDialog(this, "Patient submitted successfully.", "Success",
					JOptionPane.INFORMATION_MESSAGE);

		} catch (NumberFormatException ex) {
			JOptionPane.showMessageDialog(this, "Patient ID must be a valid number.", "Validation Error",
					JOptionPane.ERROR_MESSAGE);
			System.out.println("Error: Invalid Patient ID format.");
			ex.printStackTrace();
		} catch (Exception e) {
			System.out.println("Unexpected error in handleSubmit:");
			e.printStackTrace();
		}
	}

}
