package gui;

import model.Doctor;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * GUI for managing doctors.
 */
public class Doctorpage extends JFrame {
	private List<Doctor> doctorList;
	private JTable doctorTable;
	private DefaultTableModel doctorTableModel;

	/**
	 * Constructs the Doctorpage GUI.
	 *
	 * @param doctorList the list of doctors.
	 */
	public Doctorpage(List<Doctor> doctorList) {
		this.doctorList = doctorList;

		setTitle("Doctor Management");
		setBounds(100, 100, 600, 400);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		// Main content panel
		JPanel contentPane = new JPanel(new BorderLayout());
		setContentPane(contentPane);

		// Table Setup
		String[] columnNames = { "ID", "First Name", "Last Name" };
		doctorTableModel = new DefaultTableModel(columnNames, 0);
		doctorTable = new JTable(doctorTableModel);

		JScrollPane scrollPane = new JScrollPane(doctorTable);
		contentPane.add(scrollPane, BorderLayout.CENTER);

		// Buttons Panel
		JPanel controlPanel = new JPanel(new FlowLayout());
		JButton btnAddDoctor = new JButton("Add Doctor");
		JButton btnEditDoctor = new JButton("Edit Doctor");
		JButton btnRemoveDoctor = new JButton("Remove Doctor");

		controlPanel.add(btnAddDoctor);
		controlPanel.add(btnEditDoctor);
		controlPanel.add(btnRemoveDoctor);
		contentPane.add(controlPanel, BorderLayout.SOUTH);

		// Button Actions
		btnAddDoctor.addActionListener(e -> openDoctorForm(null));
		btnEditDoctor.addActionListener(e -> editSelectedDoctor());
		btnRemoveDoctor.addActionListener(e -> removeSelectedDoctor());

		refreshDoctorTable();
	}

	/**
	 * refreshes the doctor table with updated data.
	 */
	private void refreshDoctorTable() {
		doctorTableModel.setRowCount(0);
		for (Doctor doctor : doctorList) {
			doctorTableModel.addRow(new Object[] { doctor.getId(), doctor.getFirstName(), doctor.getLastName() });
		}
	}

	/**
	 * opens the Aadd/edit doctor form.
	 *
	 * @param existingDoctor the doctor to edit
	 */
	private void openDoctorForm(Doctor existingDoctor) {
		JDialog formDialog = new JDialog(this, existingDoctor == null ? "Add Doctor" : "Edit Doctor", true);
		formDialog.setSize(400, 300);
		formDialog.setLayout(new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(5, 5, 5, 5);

		JTextField tfFirstName = new JTextField(existingDoctor != null ? existingDoctor.getFirstName() : "", 20);
		JTextField tfLastName = new JTextField(existingDoctor != null ? existingDoctor.getLastName() : "", 20);
		JTextField tfDoctorID = new JTextField(existingDoctor != null ? String.valueOf(existingDoctor.getId()) : "",
				20);

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.LINE_END;
		formDialog.add(new JLabel("First Name:"), gbc);

		gbc.gridx = 1;
		gbc.anchor = GridBagConstraints.LINE_START;
		formDialog.add(tfFirstName, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		gbc.anchor = GridBagConstraints.LINE_END;
		formDialog.add(new JLabel("Last Name:"), gbc);

		gbc.gridx = 1;
		gbc.anchor = GridBagConstraints.LINE_START;
		formDialog.add(tfLastName, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		gbc.anchor = GridBagConstraints.LINE_END;
		formDialog.add(new JLabel("Doctor ID:"), gbc);

		gbc.gridx = 1;
		gbc.anchor = GridBagConstraints.LINE_START;
		formDialog.add(tfDoctorID, gbc);

		JButton btnSubmit = new JButton(existingDoctor == null ? "Add" : "Save");
		gbc.gridy++;
		gbc.gridx = 0;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.CENTER;
		formDialog.add(btnSubmit, gbc);

		btnSubmit.addActionListener(e -> {
			try {
				int id = Integer.parseInt(tfDoctorID.getText());
				String firstName = tfFirstName.getText().trim();
				String lastName = tfLastName.getText().trim();

				if (existingDoctor == null) {
					Doctor newDoctor = new Doctor(id, firstName, lastName);
					doctorList.add(newDoctor);
				} else {
					existingDoctor.setFirstName(firstName);
					existingDoctor.setLastName(lastName);
					existingDoctor.setId(id);
				}
				refreshDoctorTable();
				formDialog.dispose();
			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(formDialog, "Invalid ID: " + ex.getMessage());
			}
		});

		formDialog.setVisible(true);
	}

	/**
	 * edits the selected doctor.
	 */
	private void editSelectedDoctor() {
		int selectedRow = doctorTable.getSelectedRow();
		if (selectedRow != -1) {
			Doctor selectedDoctor = doctorList.get(selectedRow);
			openDoctorForm(selectedDoctor);
		} else {
			JOptionPane.showMessageDialog(this, "Please select a doctor to edit.");
		}
	}

	/**
	 * Removes the selected doctor.
	 */
	private void removeSelectedDoctor() {
		int selectedRow = doctorTable.getSelectedRow();
		if (selectedRow != -1) {
			int confirm = JOptionPane.showConfirmDialog(this, "remove this doctor?");
			if (confirm == JOptionPane.YES_OPTION) {
				doctorList.remove(selectedRow);
				refreshDoctorTable();
			}
		} else {
			JOptionPane.showMessageDialog(this, "please select a doctor to remove.");
		}
	}
}
