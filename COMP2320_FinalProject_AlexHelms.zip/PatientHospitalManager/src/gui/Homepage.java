package gui;

import model.Doctor;
import model.Nurse;
import model.Patient;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;

/**
 *GUI for navigating between patients doctors, and nurses management.
 */
public class Homepage extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	// Lists to hold patients, doctors, and nurses
	private List<Patient> patientList = new ArrayList<>();
	private List<Doctor> doctorList = new ArrayList<>();
	private List<Nurse> nurseList = new ArrayList<>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				Homepage frame = new Homepage();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	/**
	 * creates the frame.
	 */
	public Homepage() {
		setTitle("Healthcare Management System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Welcome to Healthcare Management System");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(50, 10, 500, 30);
		contentPane.add(lblNewLabel);

		JButton btnPatients = new JButton("Patients");
		btnPatients.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnPatients.setBounds(50, 70, 200, 50);
		contentPane.add(btnPatients);

		JButton btnDoctors = new JButton("Doctors");
		btnDoctors.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnDoctors.setBounds(50, 140, 200, 50);
		contentPane.add(btnDoctors);

		JButton btnNurses = new JButton("Nurses");
		btnNurses.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnNurses.setBounds(50, 210, 200, 50);
		contentPane.add(btnNurses);

		btnPatients.addActionListener((ActionEvent e) -> {
			Patientpage patientPage = new Patientpage(patientList, doctorList, nurseList);
			patientPage.setVisible(true);
		});

		btnDoctors.addActionListener((ActionEvent e) -> {
			Doctorpage doctorPage = new Doctorpage(doctorList);
			doctorPage.setVisible(true);
		});

		btnNurses.addActionListener((ActionEvent e) -> {
			Nursepage nursePage = new Nursepage(nurseList);
			nursePage.setVisible(true);
		});
	}
}
