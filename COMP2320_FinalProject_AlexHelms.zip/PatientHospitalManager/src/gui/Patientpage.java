package gui;

import model.*;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * GUI for managing patients
 */
public class Patientpage extends JFrame {
	private List<Patient> patientList;
	private List<Doctor> doctorList;
	private List<Nurse> nurseList;
	private JTable patientTable;
	private DefaultTableModel patientTableModel;

	/**
	 * constructs the Patientpage GUI.
	 *
	 * @param patients the list of patients.
	 * @param doctors  the list of available doctors.
	 * @param nurses   the list of available nurses.
	 */
	public Patientpage(List<Patient> patients, List<Doctor> doctors, List<Nurse> nurses) {
		this.patientList = patients;
		this.doctorList = doctors;
		this.nurseList = nurses;

		setTitle("Patient Management");
		setBounds(100, 100, 900, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel contentPane = new JPanel(new BorderLayout());
		setContentPane(contentPane);

		String[] columnNames = { "Select", "First Name", "Last Name", "ID", "Medications" };
		patientTableModel = new DefaultTableModel(columnNames, 0) {
			@Override
			public Class<?> getColumnClass(int columnIndex) {
				return columnIndex == 0 ? Boolean.class : String.class;
			}
		};
		patientTable = new JTable(patientTableModel);
		patientTable.getColumnModel().getColumn(0).setPreferredWidth(50);

		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
		for (int i = 1; i < columnNames.length; i++) {
			patientTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
		}

		JScrollPane scrollPane = new JScrollPane(patientTable);
		contentPane.add(scrollPane, BorderLayout.CENTER);

		JPanel controlPanel = new JPanel(new FlowLayout());
		JButton btnAddPatient = new JButton("Add Patient");
		JButton btnEditPatient = new JButton("Edit Patient");
		JButton btnRemovePatient = new JButton("Remove Patient");
		JButton btnSaveToFile = new JButton("Save to File");
		JButton btnLoadFromFile = new JButton("Load from File");

		controlPanel.add(btnAddPatient);
		controlPanel.add(btnEditPatient);
		controlPanel.add(btnRemovePatient);
		controlPanel.add(btnSaveToFile);
		controlPanel.add(btnLoadFromFile);
		contentPane.add(controlPanel, BorderLayout.SOUTH);

		btnAddPatient.addActionListener(e -> openPatientForm(null));
		btnEditPatient.addActionListener(e -> editSelectedPatient());
		btnRemovePatient.addActionListener(e -> removeSelectedPatient());
		btnSaveToFile.addActionListener(e -> savePatientsToFile());
		btnLoadFromFile.addActionListener(e -> loadPatientsFromFile());

		refreshPatientTable();
	}

	/**
	 * Refreshes the patient table
	 */
	private void refreshPatientTable() {
		patientTableModel.setRowCount(0);
		System.out.println("Refreshing Patient Table...");
		for (Patient patient : patientList) {
			System.out.println("Adding to Table: " + patient.toFileString());
			Object[] row = { false, patient.getFirstName(), patient.getLastName(), patient.getId(),
					formatMedications(patient.getMedications()) };
			patientTableModel.addRow(row);
		}
	}

	/**
	 * formats a list of medications into a readable string.
	 *
	 * @param medications the list of medications.
	 * @return a formatted string of medications.
	 */
	private String formatMedications(List<Medication> medications) {
		if (medications.isEmpty()) {
			return "No medications";
		}
		StringBuilder formatted = new StringBuilder();
		for (Medication med : medications) {
			formatted.append(med.getName()).append(" (").append(med.getDosage()).append(" mg), ");
		}
		return formatted.substring(0, formatted.length() - 2); // Remove trailing comma
	}

	/**
	 * opens the Add/Edit Patient form
	 * 
	 * @param existingPatient the patient to edit
	 */
	private void openPatientForm(Patient existingPatient) {
		Patientform form = new Patientform(existingPatient, doctorList, nurseList, e -> {
			// Handle form submission
			String[] data = e.getActionCommand().split(";");
			int id = Integer.parseInt(data[0]);
			String firstName = data[1];
			String lastName = data[2];
			String doctorName = data[3];
			String nurseName = data[4];
			String medicationsData = data[5];
			String notes = data[6];

			System.out
					.println("Received Patient Data: ID=" + id + ", FirstName=" + firstName + ", LastName=" + lastName);

			// Parse medications
			List<Medication> medications = new ArrayList<>();
			if (!medicationsData.isEmpty()) {
				String[] medicationParts = medicationsData.split(",");
				for (String med : medicationParts) {
					try {
						String[] medDetails = med.split(" \\(");
						String medName = medDetails[0].trim();
						String dosageStr = medDetails[1].replace(" mg)", "").replace("]", "").trim();
						int dosage = Integer.parseInt(dosageStr);
						medications.add(new Medication(medName, dosage));
					} catch (Exception ex) {
						System.out.println("Error parsing medication: " + med);
						ex.printStackTrace();
					}
				}
			}

			if (existingPatient == null) {
				System.out.println("Adding New Patient with ID: " + id);
				Patient newPatient = new Patient(id, firstName, lastName, findDoctorByName(doctorName),
						findNurseByName(nurseName));
				newPatient.setNotes(notes);
				for (Medication medication : medications) {
					newPatient.addMedication(medication);
				}
				patientList.add(newPatient);
			} else {
				System.out.println("Updating Existing Patient with ID: " + existingPatient.getId());
				existingPatient.setFirstName(firstName);
				existingPatient.setLastName(lastName);
				existingPatient.setId(id);
				existingPatient.setAssignedDoctor(findDoctorByName(doctorName));
				existingPatient.setAssignedNurse(findNurseByName(nurseName));
				existingPatient.clearMedications();
				for (Medication medication : medications) {
					existingPatient.addMedication(medication);
				}
				existingPatient.setNotes(notes);
			}
			refreshPatientTable();
		});

		// Display the form
		JDialog formDialog = new JDialog(this, existingPatient == null ? "Add Patient" : "Edit Patient", true);
		formDialog.setSize(700, 600);
		formDialog.setLayout(new BorderLayout());
		formDialog.add(form, BorderLayout.CENTER);
		formDialog.setVisible(true);
	}

	private Doctor findDoctorByName(String name) {
		return doctorList.stream().filter(d -> (d.getFirstName() + " " + d.getLastName()).equals(name)).findFirst()
				.orElse(null);
	}

	private Nurse findNurseByName(String name) {
		return nurseList.stream().filter(n -> (n.getFirstName() + " " + n.getLastName()).equals(name)).findFirst()
				.orElse(null);
	}

	private void editSelectedPatient() {
		int selectedRow = patientTable.getSelectedRow();
		if (selectedRow != -1) {
			Patient selectedPatient = patientList.get(selectedRow);
			openPatientForm(selectedPatient);
		} else {
			JOptionPane.showMessageDialog(this, "Please select a patient to edit.");
		}
	}

	private void removeSelectedPatient() {
		int selectedRow = patientTable.getSelectedRow();
		if (selectedRow != -1) {
			int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to remove this patient?");
			if (confirm == JOptionPane.YES_OPTION) {
				patientList.remove(selectedRow);
				refreshPatientTable();
			}
		} else {
			JOptionPane.showMessageDialog(this, "Please select a patient to remove.");
		}
	}

	private void savePatientsToFile() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Save Patients to File");
		int choice = fileChooser.showSaveDialog(this);
		if (choice == JFileChooser.APPROVE_OPTION) {
			File file = fileChooser.getSelectedFile();
			try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
				for (Patient patient : patientList) {
					writer.write(patient.toFileString());
					writer.newLine();
				}
				JOptionPane.showMessageDialog(this, "Patients saved successfully!");
			} catch (IOException e) {
				JOptionPane.showMessageDialog(this, "Error saving patients: " + e.getMessage());
			}
		}
	}

	private void loadPatientsFromFile() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Load Patients from File");
		int choice = fileChooser.showOpenDialog(this);
		if (choice == JFileChooser.APPROVE_OPTION) {
			File file = fileChooser.getSelectedFile();
			try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
				patientList.clear();
				String line;
				while ((line = reader.readLine()) != null) {
					Patient patient = Patient.fromFileString(line, doctorList, nurseList);
					patientList.add(patient);
				}
				refreshPatientTable();
				JOptionPane.showMessageDialog(this, "Patients loaded successfully!");
			} catch (IOException | IllegalArgumentException e) {
				JOptionPane.showMessageDialog(this, "Error loading patients: " + e.getMessage());
			}
		}
	}
}
