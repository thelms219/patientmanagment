package gui;

import model.Nurse;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * GUI for managing nurses.
 */
public class Nursepage extends JFrame {
	private List<Nurse> nurseList;
	private JTable nurseTable;
	private DefaultTableModel nurseTableModel;

	/**
	 * Constructs the Nursepage GUI.
	 *
	 * @param nurseList the list of nurses.
	 */
	public Nursepage(List<Nurse> nurseList) {
		this.nurseList = nurseList;

		setTitle("Nurse Management");
		setBounds(100, 100, 600, 400);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		// Main content panel
		JPanel contentPane = new JPanel(new BorderLayout());
		setContentPane(contentPane);

		// Table Setup
		String[] columnNames = { "ID", "First Name", "Last Name" };
		nurseTableModel = new DefaultTableModel(columnNames, 0);
		nurseTable = new JTable(nurseTableModel);

		JScrollPane scrollPane = new JScrollPane(nurseTable);
		contentPane.add(scrollPane, BorderLayout.CENTER);

		// Buttons Panel
		JPanel controlPanel = new JPanel(new FlowLayout());
		JButton btnAddNurse = new JButton("Add Nurse");
		JButton btnEditNurse = new JButton("Edit Nurse");
		JButton btnRemoveNurse = new JButton("Remove Nurse");

		controlPanel.add(btnAddNurse);
		controlPanel.add(btnEditNurse);
		controlPanel.add(btnRemoveNurse);
		contentPane.add(controlPanel, BorderLayout.SOUTH);

		// Button Actions
		btnAddNurse.addActionListener(e -> openNurseForm(null));
		btnEditNurse.addActionListener(e -> editSelectedNurse());
		btnRemoveNurse.addActionListener(e -> removeSelectedNurse());

		refreshNurseTable();
	}

	/**
	 * Refreshes the nurse table with updated data.
	 */
	private void refreshNurseTable() {
		nurseTableModel.setRowCount(0);
		for (Nurse nurse : nurseList) {
			nurseTableModel.addRow(new Object[] { nurse.getId(), nurse.getFirstName(), nurse.getLastName() });
		}
	}

	/**
	 * opens the add and edit nurse form.
	 *
	 * @param existingNurse the nurse to edit, or null to add a new nurse.
	 */
	private void openNurseForm(Nurse existingNurse) {
		JDialog formDialog = new JDialog(this, existingNurse == null ? "Add Nurse" : "Edit Nurse", true);
		formDialog.setSize(400, 300);
		formDialog.setLayout(new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(5, 5, 5, 5);

		JTextField tfFirstName = new JTextField(existingNurse != null ? existingNurse.getFirstName() : "", 20);
		JTextField tfLastName = new JTextField(existingNurse != null ? existingNurse.getLastName() : "", 20);
		JTextField tfNurseID = new JTextField(existingNurse != null ? String.valueOf(existingNurse.getId()) : "", 20);

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.LINE_END;
		formDialog.add(new JLabel("First Name:"), gbc);

		gbc.gridx = 1;
		gbc.anchor = GridBagConstraints.LINE_START;
		formDialog.add(tfFirstName, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		gbc.anchor = GridBagConstraints.LINE_END;
		formDialog.add(new JLabel("Last Name:"), gbc);

		gbc.gridx = 1;
		gbc.anchor = GridBagConstraints.LINE_START;
		formDialog.add(tfLastName, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		gbc.anchor = GridBagConstraints.LINE_END;
		formDialog.add(new JLabel("Nurse ID:"), gbc);

		gbc.gridx = 1;
		gbc.anchor = GridBagConstraints.LINE_START;
		formDialog.add(tfNurseID, gbc);

		// Submit Button
		JButton btnSubmit = new JButton(existingNurse == null ? "Add" : "Save");
		gbc.gridy++;
		gbc.gridx = 0;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.CENTER;
		formDialog.add(btnSubmit, gbc);

		btnSubmit.addActionListener(e -> {
			try {
				int id = Integer.parseInt(tfNurseID.getText());
				String firstName = tfFirstName.getText().trim();
				String lastName = tfLastName.getText().trim();

				if (existingNurse == null) {
					Nurse newNurse = new Nurse(id, firstName, lastName);
					nurseList.add(newNurse);
				} else {
					existingNurse.setFirstName(firstName);
					existingNurse.setLastName(lastName);
					existingNurse.setId(id);
				}
				refreshNurseTable();
				formDialog.dispose();
			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(formDialog, "Invalid ID: " + ex.getMessage());
			}
		});

		formDialog.setVisible(true);
	}

	/**
	 * Edits the selected nurse.
	 */
	private void editSelectedNurse() {
		int selectedRow = nurseTable.getSelectedRow();
		if (selectedRow != -1) {
			Nurse selectedNurse = nurseList.get(selectedRow);
			openNurseForm(selectedNurse);
		} else {
			JOptionPane.showMessageDialog(this, "select a nurse to edit.");
		}
	}

	/**
	 * Removes the selected nurse.
	 */
	private void removeSelectedNurse() {
		int selectedRow = nurseTable.getSelectedRow();
		if (selectedRow != -1) {
			int confirm = JOptionPane.showConfirmDialog(this, "sre you sure you want to remove this nurse?");
			if (confirm == JOptionPane.YES_OPTION) {
				nurseList.remove(selectedRow);
				refreshNurseTable();
			}
		} else {
			JOptionPane.showMessageDialog(this, "select a nurse to remove.");
		}
	}
}
