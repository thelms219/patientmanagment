package main;

import gui.Homepage;

public class Main {
	public static void main(String[] args) {
		Homepage homepage = new Homepage();
		homepage.setVisible(true);
	}
}
