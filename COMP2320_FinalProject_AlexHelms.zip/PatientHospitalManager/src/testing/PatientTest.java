package testing;

import model.*;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PatientTest {

    @Test
    void testValidPatientCreation() {
        Doctor doctor = new Doctor(1, "John", "Doe");
        Nurse nurse = new Nurse(2, "Jane", "Doe");

        Patient patient = new Patient(100, "John", "Doe", doctor, nurse);

        assertEquals(100, patient.getId(), "Patient ID should be 100");
        assertEquals("John", patient.getFirstName(), "Patient first name should be John");
        assertEquals("Doe", patient.getLastName(), "Patient last name should be Doe");
        assertEquals(doctor, patient.getAssignedDoctor(), "Assigned doctor should match");
        assertEquals(nurse, patient.getAssignedNurse(), "Assigned nurse should match");
    }

    @Test
    void testAddAndRemoveMedication() {
        Patient patient = new Patient(101, "John", "Doe", null, null);
        Medication med1 = new Medication("Med1", 500);
        Medication med2 = new Medication("Med2", 200);

        patient.addMedication(med1);
        patient.addMedication(med2);

        assertEquals(2, patient.getMedications().size(), "Patient should have 2 medications");
        assertTrue(patient.getMedications().contains(med1), "Medication list should contain Med1");
        assertTrue(patient.getMedications().contains(med2), "Medication list should contain Med2");

        patient.removeMedication(med1);
        assertEquals(1, patient.getMedications().size(), "Patient should have 1 medication after removal");
        assertFalse(patient.getMedications().contains(med1), "Medication list should no longer contain Med1");
    }

    @Test
    void testClearMedications() {
        Patient patient = new Patient(102, "John", "Doe", null, null);
        Medication med1 = new Medication("Med1", 100);
        Medication med2 = new Medication("Med2", 250);

        patient.addMedication(med1);
        patient.addMedication(med2);

        patient.clearMedications();

        assertEquals(0, patient.getMedications().size(), "Patient medication list should be empty after clearing");
    }

    @Test
    void testSetAndGetNotes() {
        Patient patient = new Patient(103, "John", "Doe", null, null);

        String notes = "Patient has a mild fever.";
        patient.setNotes(notes);

        assertEquals(notes, patient.getNotes(), "Notes should match the set value");
    }

    @Test
    void testToFileString() {
        Doctor doctor = new Doctor(1, "John", "Doe");
        Nurse nurse = new Nurse(2, "Jane", "Doe");
        Patient patient = new Patient(104, "John", "Doe", doctor, nurse);

        Medication med1 = new Medication("Med1", 500);
        Medication med2 = new Medication("Med2", 1000);
        patient.addMedication(med1);
        patient.addMedication(med2);

        patient.setNotes("Patient has been prescribed antibiotics.");

        String expected = "104;John;Doe;1;2;Med1 (500 mg),Med2 (1000 mg);Patient has been prescribed antibiotics.";
        assertEquals(expected, patient.toFileString(), "Serialized patient string should match expected format");
    }

    @Test
    void testFromFileString() {
        List<Doctor> doctors = new ArrayList<>();
        doctors.add(new Doctor(1, "John", "Doe"));
        List<Nurse> nurses = new ArrayList<>();
        nurses.add(new Nurse(2, "Jane", "Doe"));

        String fileString = "104;John;Doe;1;2;Med1 (500 mg),Med2 (1000 mg);Patient has been prescribed antibiotics.";

        Patient patient = Patient.fromFileString(fileString, doctors, nurses);

        assertEquals(104, patient.getId(), "Patient ID should match parsed value");
        assertEquals("John", patient.getFirstName(), "First name should match parsed value");
        assertEquals("Doe", patient.getLastName(), "Last name should match parsed value");
        assertEquals(doctors.get(0), patient.getAssignedDoctor(), "Assigned doctor should match");
        assertEquals(nurses.get(0), patient.getAssignedNurse(), "Assigned nurse should match");
        assertEquals(2, patient.getMedications().size(), "Medication list size should match parsed value");
        assertEquals("Patient has been prescribed antibiotics.", patient.getNotes(), "Notes should match parsed value");
    }

    @Test
    void testFromFileStringInvalidFormat() {
        List<Doctor> doctors = new ArrayList<>();
        List<Nurse> nurses = new ArrayList<>();

        String invalidFileString = "Invalid;Data";

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            Patient.fromFileString(invalidFileString, doctors, nurses);
        });

        assertEquals("Invalid file string for Patient.", exception.getMessage());
    }

    @Test
    void testAddNullMedication() {
        Patient patient = new Patient(105, "John", "Doe", null, null);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            patient.addMedication(null);
        });

        assertEquals("Medication cannot be null.", exception.getMessage());
    }
}
