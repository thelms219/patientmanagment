package testing;

import model.Doctor;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DoctorTest {

    @Test
    void testValidDoctorCreation() {
        Doctor doctor = new Doctor(1, "John", "Doe");

        assertEquals(1, doctor.getId(), "Doctor ID should be 1");
        assertEquals("John", doctor.getFirstName(), "Doctor first name should be John");
        assertEquals("Doe", doctor.getLastName(), "Doctor last name should be Doe");
    }

    @Test
    void testToString() {
        Doctor doctor = new Doctor(2, "Joe", "Smith");

        String expected = "Joe Smith (ID: 2)"; 
        assertEquals(expected, doctor.toString(), "toString output should match the expected format");
    }

    @Test
    void testSetters() {
        Doctor doctor = new Doctor(3, "James", "Wilson");

        doctor.setFirstName("Jim");
        doctor.setLastName("Cameron");
        doctor.setId(4);

        assertEquals(4, doctor.getId(), "Doctor ID should be updated to 4");
        assertEquals("Jim", doctor.getFirstName(), "Doctor first name should be updated to Jim");
        assertEquals("Cameron", doctor.getLastName(), "Doctor last name should be updated to Cameron");
    }
}
