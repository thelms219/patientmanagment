package testing;

import model.Nurse;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NurseTest {

    @Test
    void testValidNurseCreation() {
        Nurse nurse = new Nurse(1, "Jane", "Doe");

        assertEquals(1, nurse.getId(), "Nurse ID should be 1");
        assertEquals("Jane", nurse.getFirstName(), "Nurse first name should be Jane");
        assertEquals("Doe", nurse.getLastName(), "Nurse last name should be Doe");
    }

    @Test
    void testToString() {
        Nurse nurse = new Nurse(2, "Mary", "Smith");

        String expected = "Mary Smith (ID: 2)";
        assertEquals(expected, nurse.toString(), "toString output should match the expected format");
    }

    @Test
    void testSetters() {
        Nurse nurse = new Nurse(3, "Anna", "Jones");

        // Modify properties using setters (inherited from Person)
        nurse.setFirstName("Anne");
        nurse.setLastName("Johnson");
        nurse.setId(4);

        assertEquals(4, nurse.getId(), "Nurse ID should be updated to 4");
        assertEquals("Anne", nurse.getFirstName(), "Nurse first name should be updated to Anne");
        assertEquals("Johnson", nurse.getLastName(), "Nurse last name should be updated to Johnson");
    }
}
