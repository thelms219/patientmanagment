package testing;

import static org.junit.jupiter.api.Assertions.*;

import model.Medication;
import org.junit.jupiter.api.Test;

class MedicationTest {

    @Test
    void testValidMedicationCreation() {
        Medication med = new Medication("Med 1", 500);
        assertEquals("Med 1", med.getName(), "The name should be Med 1");
        assertEquals(500, med.getDosage(), "The dosage should be 500");
    }

    @Test
    void testMedicationNameCannotBeNull() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Medication(null, 500);
        });
        assertEquals("Medication name cannot be null or empty.", exception.getMessage());
    }

    @Test
    void testMedicationNameCannotBeEmpty() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Medication("", 500);
        });
        assertEquals("Medication name cannot be null or empty.", exception.getMessage());
    }

    @Test
    void testMedicationDosageCannotBeZero() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Medication("Med 1", 0);
        });
        assertEquals("Dosage must be greater than 0.", exception.getMessage());
    }

    @Test
    void testMedicationDosageCannotBeNegative() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Medication("Med 1", -100);
        });
        assertEquals("Dosage must be greater than 0.", exception.getMessage());
    }

    @Test
    void testSetValidMedicationName() {
        Medication med = new Medication("Med 1", 500);
        med.setName("Med 2");
        assertEquals("Med 2", med.getName(), "The name should be updated to Ibuprofen");
    }

    @Test
    void testSetValidDosage() {
        Medication med = new Medication("Med 1", 500);
        med.setDosage(250);
        assertEquals(250, med.getDosage(), "The dosage should be updated to 250");
    }

    @Test
    void testToFileString() {
        Medication med = new Medication("Med1", 300);
        assertEquals("Med1:300", med.toFileString(), "The file string should be Med1:300");
    }

    @Test
    void testFromFileStringValid() {
        Medication med = Medication.fromFileString("Med:200");
        assertEquals("Med", med.getName(), "The name should be Med"); // Update expected value
        assertEquals(200, med.getDosage(), "The dosage should be 200");
    }


    @Test
    void testFromFileStringInvalidFormat() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            Medication.fromFileString("InvalidString");
        });
        assertEquals("Invalid file for Medication.", exception.getMessage()); 
    }


    @Test
    void testToString() {
        Medication med = new Medication("Med", 500);
        assertEquals("Med (500 mg)", med.toString(), "The toString should match the expected format");
    }
}
