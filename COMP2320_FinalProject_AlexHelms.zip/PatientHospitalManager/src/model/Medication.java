package model;

/**
 * Medication with a name and dosage.
 */
public class Medication {
	private String name;
	private int dosage;

	public Medication(String name, int dosage) {
		if (name == null || name.isEmpty()) {
			throw new IllegalArgumentException("Medication name cannot be null or empty.");
		}
		if (dosage <= 0) {
			throw new IllegalArgumentException("Dosage must be greater than 0.");
		}
		this.name = name;
		this.dosage = dosage;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		if (name == null || name.isEmpty()) {
			throw new IllegalArgumentException("Medication name cannot be null or empty.");
		}
		this.name = name;
	}

	public int getDosage() {
		return dosage;
	}

	public void setDosage(int dosage) {
		if (dosage <= 0) {
			throw new IllegalArgumentException("Dosage must be greater than 0.");
		}
		this.dosage = dosage;
	}

	/**
	 * Converts the Medication tostring format.
	 *
	 * @return a formatted string of the medication.
	 */
	public String toFileString() {
		return name + ":" + dosage;
	}

	/**
	 * Parses a string to create a Medication object.
	 *
	 * @param fileString the string to parse.
	 * @return a Medication object.
	 */
	public static Medication fromFileString(String fileString) {
		if (fileString.matches(".* \\(\\d+ mg\\)")) {
			int startIndex = fileString.lastIndexOf("(");
			int endIndex = fileString.lastIndexOf("mg)");
			String name = fileString.substring(0, startIndex).trim();
			int dosage = Integer.parseInt(fileString.substring(startIndex + 1, endIndex).trim());
			return new Medication(name, dosage);
		}

		String[] parts = fileString.split(":");
		if (parts.length == 2) {
			String name = parts[0].trim();
			int dosage = Integer.parseInt(parts[1].trim());
			return new Medication(name, dosage);
		}

		throw new IllegalArgumentException("Invalid file for Medication.");
	}

	@Override
	public String toString() {
		return name + " (" + dosage + " mg)";
	}
}
