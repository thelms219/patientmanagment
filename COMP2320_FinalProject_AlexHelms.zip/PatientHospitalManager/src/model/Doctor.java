package model;

public class Doctor extends Person {
    public Doctor(int id, String firstName, String lastName) {
        super(id, firstName, lastName);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
