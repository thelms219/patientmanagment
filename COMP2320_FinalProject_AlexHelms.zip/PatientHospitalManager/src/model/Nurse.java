package model;

public class Nurse extends Person {
    public Nurse(int id, String firstName, String lastName) {
        super(id, firstName, lastName);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
