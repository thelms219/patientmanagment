package model;

/**
 * Abstract class representing a person with an ID, first name, and last name.
 */
public abstract class Person {
	private int id;
	private String firstName;
	private String lastName;

	/**
	 * constructs a Person with an ID, first name, and last name.
	 *
	 * @param id        the ID for the person.
	 * @param firstName the first name of the person.
	 * @param lastName  the last name of the person.
	 */
	public Person(int id, String firstName, String lastName) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	/**
	 * Gets the ID of the person.
	 *
	 * @return the ID of the person.
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the ID of the person.
	 *
	 * @param id the new ID of the person.
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the first name of the person.
	 *
	 * @return the first name of the person.
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the first name of the person.
	 *
	 * @param firstName the new first name of the person.
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the last name of the person.
	 *
	 * @return the last name of the person.
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the last name of the person.
	 *
	 * @param lastName the new last name of the person.
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return firstName + " " + lastName + " (ID: " + id + ")";
	}
}
