package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a Patient with assigned doctor, nurse, medications, and notes.
 */
public class Patient extends Person {
	private Doctor assignedDoctor;
	private Nurse assignedNurse;
	private List<Medication> medications;
	private String notes;

	/**
	 * Constructs a Patient object.
	 *
	 * @param id             the patient ID.
	 * @param firstName      the first name of the patient.
	 * @param lastName       the last name of the patient.
	 * @param assignedDoctor the assigned doctor.
	 * @param assignedNurse  the assigned nurse.
	 */
	public Patient(int id, String firstName, String lastName, Doctor assignedDoctor, Nurse assignedNurse) {
		super(id, firstName, lastName);
		this.assignedDoctor = assignedDoctor;
		this.assignedNurse = assignedNurse;
		this.medications = new ArrayList<>();
		this.notes = "";
	}

	// Getters and setters
	public Doctor getAssignedDoctor() {
		return assignedDoctor;
	}

	public void setAssignedDoctor(Doctor assignedDoctor) {
		this.assignedDoctor = assignedDoctor;
	}

	public Nurse getAssignedNurse() {
		return assignedNurse;
	}

	public void setAssignedNurse(Nurse assignedNurse) {
		this.assignedNurse = assignedNurse;
	}

	public List<Medication> getMedications() {
		return new ArrayList<>(medications); // Return a copy for encapsulation
	}

	public void addMedication(Medication medication) {
		if (medication == null) {
			throw new IllegalArgumentException("Medication cannot be null.");
		}
		this.medications.add(medication);
	}

	public void removeMedication(Medication medication) {
		this.medications.remove(medication);
	}

	public void clearMedications() {
		this.medications.clear();
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	/**
	 * Formats the patient data into a savable string.
	 *
	 * @return a formatted string representation of the patient.
	 */
	public String toFileString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getId()).append(";");
		sb.append(getFirstName()).append(";");
		sb.append(getLastName()).append(";");
		sb.append(assignedDoctor != null ? assignedDoctor.getId() : "null").append(";");
		sb.append(assignedNurse != null ? assignedNurse.getId() : "null").append(";");
		sb.append(formatMedicationsForFile()).append(";");
		sb.append(notes.replace("\n", "\\n")); // Replace newlines for file compatibility
		return sb.toString();
	}

	/**
	 * Parses a file string to create a Patient
	 *
	 * @param fileString the string to parse.
	 * @param doctors    the list of available doctors to match by ID.
	 * @param nurses     the list of available nurses to match by ID.
	 * @return a Patient object.
	 */
	public static Patient fromFileString(String fileString, List<Doctor> doctors, List<Nurse> nurses) {
		String[] parts = fileString.split(";");
		if (parts.length < 7) {
			throw new IllegalArgumentException("Invalid file string for Patient.");
		}

		int id = Integer.parseInt(parts[0]);
		String firstName = parts[1];
		String lastName = parts[2];

		// match doctor and nurse by ID
		Doctor doctor = findById(doctors, parts[3]);
		Nurse nurse = findById(nurses, parts[4]);

		Patient patient = new Patient(id, firstName, lastName, doctor, nurse);

		String[] medicationParts = parts[5].split(",");
		for (String medString : medicationParts) {
			if (!medString.trim().isEmpty()) {
				patient.addMedication(Medication.fromFileString(medString));
			}
		}

		// Set notes
		patient.setNotes(parts[6].replace("\\n", "\n"));

		return patient;
	}

	/**
	 * Formats the medications into a savable string.
	 *
	 * @return a formatted string of medications.
	 */
	private String formatMedicationsForFile() {
		StringBuilder sb = new StringBuilder();
		for (Medication medication : medications) {
			sb.append(medication.toString()).append(",");
		}
		if (sb.length() > 0) {
			sb.setLength(sb.length() - 1); // Remove trailing comma
		}
		return sb.toString();
	}

	/**
	 * Finds a doctor or nurse by ID from a list.
	 *
	 * @param list the list of doctors or nurses.
	 * @param id   the ID to search for.
	 * @param <T>  the type of object (Doctor or Nurse).
	 * @return the matched object or null if not found.
	 */
	private static <T extends Person> T findById(List<T> list, String id) {
		if (id.equals("null")) {
			return null;
		}
		int intId = Integer.parseInt(id);
		for (T item : list) {
			if (item.getId() == intId) {
				return item;
			}
		}
		return null;
	}

	@Override
	public String toString() {
		String doctorName = assignedDoctor != null ? assignedDoctor.getFirstName() + " " + assignedDoctor.getLastName()
				: "Unassigned";
		String nurseName = assignedNurse != null ? assignedNurse.getFirstName() + " " + assignedNurse.getLastName()
				: "Unassigned";

		return super.toString() + " - Doctor: " + doctorName + ", Nurse: " + nurseName + ", Medications: "
				+ formatMedicationsForFile();
	}
}
